﻿
namespace DbDiffer.Membership
{
    public class ResetPasswordModel
    {
        public string Token { get; set; }
    }
}