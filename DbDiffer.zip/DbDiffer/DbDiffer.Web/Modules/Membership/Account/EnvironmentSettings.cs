﻿
namespace DbDiffer
{
    public class EnvironmentSettings
    {
        public string SiteExternalUrl { get; set; }
    }
}