﻿
namespace DbDiffer.Db {

    @Serenity.Decorators.registerClass()
    export class TableColumnDialog extends Serenity.EntityDialog<TableColumnRow, any> {
        protected getFormKey() { return TableColumnForm.formKey; }
        protected getIdProperty() { return TableColumnRow.idProperty; }
        protected getLocalTextPrefix() { return TableColumnRow.localTextPrefix; }
        protected getNameProperty() { return TableColumnRow.nameProperty; }
        protected getService() { return TableColumnService.baseUrl; }
        protected getDeletePermission() { return TableColumnRow.deletePermission; }
        protected getInsertPermission() { return TableColumnRow.insertPermission; }
        protected getUpdatePermission() { return TableColumnRow.updatePermission; }

        protected form = new TableColumnForm(this.idPrefix);

    }
}