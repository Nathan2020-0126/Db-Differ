﻿
namespace DbDiffer.Db.Entities
{
    using Mom.Administration.Entities;
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using Serenity.Data.Mapping;
    using System;
    using System.ComponentModel;
    using System.IO;

    [ConnectionKey("Default"), Module("Db"), TableName("[dbo].[TableColumn]")]
    [DisplayName("列"), InstanceName("列")]
    [ReadPermission("*")]
    [ModifyPermission("*")]
    [LookupScript]
    public sealed class TableColumnRow : LoggingAllRow, IIdRow, INameRow
    {
        [DisplayName("Table Column Id")]
        public Guid? TableColumnId
        {
            get { return Fields.TableColumnId[this]; }
            set { Fields.TableColumnId[this] = value; }
        }
        [QuickFilter]
        [LookupEditor(typeof(DatabaseRow))]
        [ForeignKey("Databases", "DatabaseId"),LeftJoin("jDatabase")]
        public Guid? DatabaseId {
            get { return Fields.DatabaseId[this]; }
            set { Fields.DatabaseId[this] = value; }
        }
        [DisplayName("数据库"),Expression("jDatabase.DatabaseName")]
        public String DatabaseName {
            get { return Fields.DatabaseName[this]; }
            set { Fields.DatabaseName[this] = value; }
        }

        [DisplayName("表名称"), Size(500), QuickSearch]
        [Column("TableName")]
        [LookupEditor(typeof(TableColumnRow))]
        [QuickFilter]
        public String Table_Name
        {
            get { return Fields.Table_Name[this]; }
            set { Fields.Table_Name[this] = value; }
        }

        [DisplayName("字段名称"), Size(50)]
        public String Name
        {
            get { return Fields.Name[this]; }
            set { Fields.Name[this] = value; }
        }

        [DisplayName("序号")]
        public Int32? Item
        {
            get { return Fields.Item[this]; }
            set { Fields.Item[this] = value; }
        }

        [DisplayName("是否标识")]
        public Boolean? IsIdentity
        {
            get { return Fields.IsIdentity[this]; }
            set { Fields.IsIdentity[this] = value; }
        }

        [DisplayName("是否主键")]
        public Boolean? IsPk
        {
            get { return Fields.IsPk[this]; }
            set { Fields.IsPk[this] = value; }
        }

        [DisplayName("类型"), Size(50)]
        public String Type
        {
            get { return Fields.Type[this]; }
            set { Fields.Type[this] = value; }
        }

        [DisplayName("占用字节")]
        public Int32? OccupiedBytes
        {
            get { return Fields.OccupiedBytes[this]; }
            set { Fields.OccupiedBytes[this] = value; }
        }

        [DisplayName("长度")]
        public Int32? Length
        {
            get { return Fields.Length[this]; }
            set { Fields.Length[this] = value; }
        }

        [DisplayName("小数位数")]
        public Int32? DecimalPlaces
        {
            get { return Fields.DecimalPlaces[this]; }
            set { Fields.DecimalPlaces[this] = value; }
        }

        [DisplayName("是否可空")]
        public Boolean? Isnullable
        {
            get { return Fields.Isnullable[this]; }
            set { Fields.Isnullable[this] = value; }
        }

        [DisplayName("默认值"), Size(500)]
        public String DefaultValue
        {
            get { return Fields.DefaultValue[this]; }
            set { Fields.DefaultValue[this] = value; }
        }

        [DisplayName("描述")]
        public String Description
        {
            get { return Fields.Description[this]; }
            set { Fields.Description[this] = value; }
        }

        IIdField IIdRow.IdField
        {
            get { return Fields.TableColumnId; }
        }

        StringField INameRow.NameField
        {
            get { return Fields.Name; }
        }

        public static readonly RowFields Fields = new RowFields().Init();

        public TableColumnRow()
            : base(Fields)
        {
        }

        public class RowFields : LoggingAllRowFields
        {
            public GuidField TableColumnId;
            public GuidField DatabaseId;
            public StringField DatabaseName;
            public StringField Table_Name;
            public StringField Name;
            public Int32Field Item;
            public BooleanField IsIdentity;
            public BooleanField IsPk;
            public StringField Type;
            public Int32Field OccupiedBytes;
            public Int32Field Length;
            public Int32Field DecimalPlaces;
            public BooleanField Isnullable;
            public StringField DefaultValue;
            public StringField Description;
        }
    }
}
