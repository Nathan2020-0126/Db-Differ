﻿
namespace DbDiffer.Db.Columns
{
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using System;
    using System.ComponentModel;
    using System.Collections.Generic;
    using System.IO;

    [ColumnsScript("Db.TableColumn")]
    [BasedOnRow(typeof(Entities.TableColumnRow), CheckNames = true)]
    public class TableColumnColumns
    {
        
        [QuickFilter]
        public String DatabaseName { get; set; }
        [ QuickFilter]
        public String Table_Name { get; set; }
        [ QuickFilter]
        public String Name { get; set; }
        public Int32 Item { get; set; }
        public Boolean IsIdentity { get; set; }
        public Boolean IsPk { get; set; }
        public String Type { get; set; }
        public Int32 OccupiedBytes { get; set; }
        public Int32 Length { get; set; }
        public Int32 DecimalPlaces { get; set; }
        public Boolean Isnullable { get; set; }
        public String DefaultValue { get; set; }
        public String Description { get; set; }
    }
}