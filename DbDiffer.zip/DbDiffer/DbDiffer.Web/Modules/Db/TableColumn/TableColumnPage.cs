﻿
namespace DbDiffer.Db.Pages
{
    using Serenity;
    using Serenity.Web;
    using Microsoft.AspNetCore.Mvc;

    [PageAuthorize(typeof(Entities.TableColumnRow))]
    public class TableColumnController : Controller
    {
        [Route("Db/TableColumn")]
        public ActionResult Index()
        {
            return View("~/Modules/Db/TableColumn/TableColumnIndex.cshtml");
        }
    }
}