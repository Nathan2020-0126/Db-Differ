﻿using Serenity.Navigation;
using MyPages = DbDiffer.Db.Pages;

[assembly: NavigationMenu(100, "数据库", icon: "fa-database")]
[assembly: NavigationLink(100, "数据库/数据库", typeof(MyPages.DatabaseController), icon: "fa-database")]
[assembly: NavigationLink(100, "数据库/表", typeof(MyPages.TableController), icon: "fa-table")]
[assembly: NavigationLink(100, "数据库/字段", typeof(MyPages.TableColumnController), icon: "fa-columns")]