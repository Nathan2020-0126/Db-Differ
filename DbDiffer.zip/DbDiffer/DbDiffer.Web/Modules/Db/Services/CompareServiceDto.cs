﻿using Serenity.Services;
using System;

namespace DbDiffer.Db.Services.Dto
{
    public class GuidIdRequest:ServiceRequest
    {
        public Guid GuidId;
    }
    public class ChangeTableColumnDescriptionRequest : ServiceRequest {
        public Guid TableColumnId;
        public String NewDescription;
    }
}
