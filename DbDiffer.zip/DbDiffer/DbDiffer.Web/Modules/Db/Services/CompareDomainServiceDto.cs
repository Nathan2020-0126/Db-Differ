﻿using Serenity.Services;
using System;

namespace DbDiffer.Db.Services.Dto
{
    public static class DBStrings_SQLServer
    {
        public static string ProviderName = "System.Data.SqlClient";
        public static string GetTables = "select object_id as ObjectId,a.name as Name,create_date as CreateDate,modify_date as ModifyDate,max_column_id_used as ColumnCount,b.value as Description from sys.tables a LEFT JOIN sys.extended_properties b ON a.object_id = b.major_id and minor_id=0";
        public static string GetTableColumn = "" +
            "SELECT d.name as Table_Name, a.colorder as Item, a.name as Name," +
      "(case when COLUMNPROPERTY(a.id, a.name,'IsIdentity')=1 then 1 else 0 end) as IsIdentity," +
      "(case when(SELECT count(*) FROM sysobjects " +
      "WHERE (name in (SELECT name FROM sysindexes WHERE (id = a.id) AND(indid in (SELECT indid " +
      "FROM sysindexkeys WHERE (id = a.id) AND(colid in " +
      "(SELECT colid FROM syscolumns WHERE (id = a.id) AND(name = a.name))))))) AND " +
     "(xtype = 'PK'))>0 then 1 else 0 end) as IsPk,b.name as Type,a.length as OccupiedBytes," +
      "COLUMNPROPERTY(a.id, a.name,'PRECISION') as Length," +
      "isnull(COLUMNPROPERTY(a.id, a.name,'Scale'),0) as DecimalPlaces," +
      "(case when a.isnullable=1 then 1 else 0 end) as Isnullable," +
      "isnull(e.text,'') as DefaultValue,isnull(g.value,'') AS Description " +
"FROM syscolumns  a left join systypes b on  a.xtype=b.xusertype " +
"inner join sysobjects d on a.id=d.id and  d.xtype='U' and d.name<>'dtproperties' " +
"left join syscomments e on a.cdefault= e.id left join sys.extended_properties g " +
"on a.id= g.major_id AND a.colid = g.Minor_id order by d.name, a.id, a.colorder ";
    }
}

