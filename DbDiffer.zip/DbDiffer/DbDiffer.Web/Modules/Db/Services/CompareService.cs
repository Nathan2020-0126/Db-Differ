﻿using DbDiffer.Db.Entities;
using DbDiffer.Db.Services.Dto;
using Microsoft.AspNetCore.Mvc;
using Serenity.Data;
using Serenity.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DbDiffer.Db.Services
{
    [Route("Services/Db/CompareService/[action]")]
    [ConnectionKey("Default")]
    public class CompareController: ServiceEndpoint
    {
        public CompareDomainService DomainService = new CompareDomainService { };
        public ServiceResponse GetDbContent(IUnitOfWork uow, GuidIdRequest request) {
            ServiceResponse r = new ServiceResponse { };
            DatabaseRow database = uow.Connection.ById<DatabaseRow>(request.GuidId);
            DomainService.GetTables(uow, database);
            DomainService.GetColumns(uow, database);
            return r;
        }
        public ServiceResponse ChangeTableColumnDescription(IUnitOfWork uow, ChangeTableColumnDescriptionRequest request ) {
            ServiceResponse r = new ServiceResponse { };
            TableColumnRow tableColumn = uow.Connection.ById<TableColumnRow>(request.TableColumnId);
            DatabaseRow database = uow.Connection.ById<DatabaseRow>(tableColumn.DatabaseId);
            DomainService.ChangeColumnDescription(uow,database, tableColumn, request.NewDescription);
            return r;
        }
    }
}
