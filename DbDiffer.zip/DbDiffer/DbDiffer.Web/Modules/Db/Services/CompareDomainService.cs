﻿using DbDiffer.Db.Entities;
using DbDiffer.Db.Repositories;
using DbDiffer.Db.Services.Dto;
using Mom.Common.Enum;
using Serenity;
using Serenity.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DbDiffer.Db.Services
{
    public class CompareDomainService
    {
        public void GetTables(IUnitOfWork uow, DatabaseRow database)
        {
            var conn = SqlConnections.New(database.ConnectionString, DBStrings_SQLServer.ProviderName);
            var tables = conn.Query<TableRow>(DBStrings_SQLServer.GetTables).ToList();
            uow.Connection.Execute($"update dbo.[Table] set IsActive=-1 where DatabaseId='{database.DatabaseId}'");
            tables.ForEach(e=> {
                e.DatabaseId = database.DatabaseId;
                TableRow _table = uow.Connection.TrySingle<TableRow>(TableRow.Fields.Name==e.Name && TableRow.Fields.DatabaseId== (Guid)database.DatabaseId);
                if (_table == null)
                {
                    if (e.DatabaseName.IndexOf("_") > 0) {
                        e.Module = e.DatabaseName.Split("_")[0];
                    }
                    e.Id = Guid.NewGuid();
                    e.IsActive = ActiveStatus.Active;
                    e.InsertUserId = Int32.Parse(Authorization.UserId);
                    e.InsertDate = DateTime.Now;
                    uow.Connection.Insert<TableRow>(e);
                }
                else {
                    e.Id = _table.Id;
                    e.IsActive = ActiveStatus.Active;
                    e.UpdateUserId = Int32.Parse(Authorization.UserId);
                    e.UpdateDate = DateTime.Now;
                    uow.Connection.UpdateById<TableRow>(e);
                }
                
            });

        }
        public void GetColumns(IUnitOfWork uow, DatabaseRow database) {
            var conn = SqlConnections.New(database.ConnectionString, DBStrings_SQLServer.ProviderName);
            string sql = DBStrings_SQLServer.GetTableColumn;
            uow.Connection.Execute($"update TableColumn set IsActive=-1 where DatabaseId='{database.DatabaseId}'");
            var columns = conn.Query<TableColumnRow>(sql).ToList();
            columns.ForEach(e => {
                e.DatabaseId = database.DatabaseId;
                TableColumnRow _column = uow.Connection.TrySingle<TableColumnRow>(TableColumnRow.Fields.Table_Name==e.Table_Name && TableColumnRow.Fields.Name ==e.Name && TableColumnRow.Fields.DatabaseId==(Guid)database.DatabaseId);
                if (_column == null)
                {
                    e.TableColumnId = Guid.NewGuid();
                    e.IsActive = ActiveStatus.Active;
                    e.InsertUserId = Int32.Parse(Authorization.UserId);
                    e.InsertDate = DateTime.Now;
                    uow.Connection.Insert<TableColumnRow>(e);                    
                }
                else
                {
                    e.TableColumnId = _column.TableColumnId;
                    e.IsActive = ActiveStatus.Active;
                    e.UpdateUserId = Int32.Parse(Authorization.UserId);
                    e.UpdateDate = DateTime.Now;
                    uow.Connection.UpdateById<TableColumnRow>(e);
                }

            });
        }

        public void ChangeColumnDescription(IUnitOfWork uow, DatabaseRow database, TableColumnRow tableColumn, String NewDescription) {
            var conn = SqlConnections.New(database.ConnectionString, DBStrings_SQLServer.ProviderName);
            string sql;
            if (string.IsNullOrEmpty(tableColumn.Description))
            {
                sql = $"EXEC sys.sp_addextendedproperty @name = N'MS_Description', @value = N'{NewDescription}',@level0type = N'SCHEMA',@level0name = N'dbo',@level1type = N'TABLE',@level1name = N'{tableColumn.Table_Name}',@level2type = N'COLUMN',@level2name = N'{tableColumn.Name}'";
            }
            else {
                sql = $"EXEC sp_updateextendedproperty 'MS_Description','{NewDescription}','user',dbo,'table','{tableColumn.Table_Name}','column',{tableColumn.Name}";
            }
            
            
            conn.Execute(sql);
            new TableColumnRepository().Update(uow, new Serenity.Services.SaveRequest<TableColumnRow> { 
                Entity=new TableColumnRow { 
                    TableColumnId=tableColumn.TableColumnId,
                    Description=NewDescription
                }
            });
        }
        public void ChangeTableDescription(DatabaseRow database, TableRow table, String NewDescription)
        {
            var conn = SqlConnections.New(database.ConnectionString, DBStrings_SQLServer.ProviderName);
            string sql;
            if (table==null || string.IsNullOrEmpty(table.Description))
            {
                sql = $"EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'{NewDescription}' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'{table.Name}'";
            }
            else
            {
                sql = $"EXEC sys.sp_updateextendedproperty @name=N'MS_Description', @value=N'{NewDescription}' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'{table.Name}'";
            }

            conn.Execute(sql);
        }
    }
}
