﻿
namespace DbDiffer.Db.Forms
{
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using System;
    using System.ComponentModel;
    using System.Collections.Generic;
    using System.IO;

    [FormScript("Db.Table")]
    [BasedOnRow(typeof(Entities.TableRow), CheckNames = true)]
    public class TableForm
    {
        [ReadOnly(true)]
        public String Name { get; set; }
        public String Module { get; set; }
        public String Description { get; set; }
}
}