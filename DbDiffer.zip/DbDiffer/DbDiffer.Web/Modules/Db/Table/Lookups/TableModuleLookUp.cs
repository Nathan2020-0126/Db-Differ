﻿namespace Mom.Db.Lookups
{
    using DbDiffer.Db.Entities;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using Serenity.Web;

    [LookupScript]
    public class TableModuleLookUp : RowLookupScript<TableRow>
    {
        public TableModuleLookUp()
        {
            IdField = TextField = "Module";
        }

        protected override void PrepareQuery(SqlQuery query)
        {
            var fld = TableRow.Fields;
            query.Distinct(true)
                .Select(fld.Module)
                .Where(
                    new Criteria(fld.Module) != "" &
                    new Criteria(fld.Module).IsNotNull());
        }

        protected override void ApplyOrder(SqlQuery query)
        {
        }
    }
}