﻿
namespace DbDiffer.Db.Entities
{
    using Mom.Administration.Entities;
    using Mom.Db.Lookups;
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using Serenity.Data.Mapping;
    using System;
    using System.ComponentModel;
    using System.IO;

    [ConnectionKey("Default"), Module("Db"), TableName("[dbo].[Table]")]
    [DisplayName("表"), InstanceName("表")]
    [ReadPermission("*")]
    [ModifyPermission("*")]
    [LookupScript]
    public sealed class TableRow : LoggingAllRow, IIdRow, INameRow
    {
        [DisplayName("Id"), NotNull]
        public Guid? Id
        {
            get { return Fields.Id[this]; }
            set { Fields.Id[this] = value; }
        }

        [DisplayName("Database Id"), NotNull]
        [LookupEditor(typeof(DatabaseRow))]
        [ForeignKey("Databases", "DatabaseId"),LeftJoin("jDatabase")]
        public Guid? DatabaseId
        {
            get { return Fields.DatabaseId[this]; }
            set { Fields.DatabaseId[this] = value; }
        }
        [DisplayName("数据库"),Expression("jDatabase.DatabaseName")]
        public String DatabaseName {
            get { return Fields.DatabaseName[this]; }
            set { Fields.DatabaseName[this] = value; }
        }
        [DisplayName("模块")]
        [LookupEditor(typeof(TableModuleLookUp))]
        public String Module {
            get { return Fields.Module[this]; }
            set { Fields.Module[this] = value; }
        }
        [DisplayName("表"), Size(50), NotNull, QuickSearch]
        public String Name
        {
            get { return Fields.Name[this]; }
            set { Fields.Name[this] = value; }
        }

        [DisplayName("Object Id"), Size(50), NotNull]
        public String ObjectId
        {
            get { return Fields.ObjectId[this]; }
            set { Fields.ObjectId[this] = value; }
        }

        [DisplayName("创建日期"), NotNull]
        public DateTime? CreateDate
        {
            get { return Fields.CreateDate[this]; }
            set { Fields.CreateDate[this] = value; }
        }

        [DisplayName("修改日期"), NotNull]
        public DateTime? ModifyDate
        {
            get { return Fields.ModifyDate[this]; }
            set { Fields.ModifyDate[this] = value; }
        }

        [DisplayName("列数量"), NotNull]
        public Int32? ColumnCount
        {
            get { return Fields.ColumnCount[this]; }
            set { Fields.ColumnCount[this] = value; }
        }
        [DisplayName("描述")]
        public String Description {
            get { return Fields.Description[this]; }
            set { Fields.Description[this] = value; }
        }
        IIdField IIdRow.IdField
        {
            get { return Fields.Id; }
        }

        StringField INameRow.NameField
        {
            get { return Fields.Name; }
        }

        public static readonly RowFields Fields = new RowFields().Init();

        public TableRow()
            : base(Fields)
        {
        }

        public class RowFields : LoggingAllRowFields
        {
            public GuidField Id;
            public GuidField DatabaseId;
            public StringField DatabaseName;
            public StringField Module;
            public StringField Name;
            public StringField ObjectId;
            public DateTimeField CreateDate;
            public DateTimeField ModifyDate;
            public Int32Field ColumnCount;
            public StringField Description;
        }
    }
}
