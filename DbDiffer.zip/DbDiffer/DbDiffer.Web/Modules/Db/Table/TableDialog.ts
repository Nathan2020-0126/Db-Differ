﻿
namespace DbDiffer.Db {

    @Serenity.Decorators.registerClass()
    export class TableDialog extends Serenity.EntityDialog<TableRow, any> {
        protected getFormKey() { return TableForm.formKey; }
        protected getIdProperty() { return TableRow.idProperty; }
        protected getLocalTextPrefix() { return TableRow.localTextPrefix; }
        protected getNameProperty() { return TableRow.nameProperty; }
        protected getService() { return TableService.baseUrl; }
        protected getDeletePermission() { return TableRow.deletePermission; }
        protected getInsertPermission() { return TableRow.insertPermission; }
        protected getUpdatePermission() { return TableRow.updatePermission; }

        protected form = new TableForm(this.idPrefix);

    }
}