﻿
namespace DbDiffer.Db.Columns
{
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using System;
    using System.ComponentModel;
    using System.Collections.Generic;
    using System.IO;

    [ColumnsScript("Db.Table")]
    [BasedOnRow(typeof(Entities.TableRow), CheckNames = true)]
    public class TableColumns
    {
        [QuickFilter]
        public String DatabaseName { get; set; }
        public String Module { get; set; }
        [EditLink]
        public String Name { get; set; }
        public String ObjectId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime ModifyDate { get; set; }
        public Int32 ColumnCount { get; set; }
        public String Description { get; set; }
    }
}