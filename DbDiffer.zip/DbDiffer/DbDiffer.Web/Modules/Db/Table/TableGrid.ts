﻿
namespace DbDiffer.Db {

    @Serenity.Decorators.registerClass()
    export class TableGrid extends Serenity.EntityGrid<TableRow, any> {
        protected getColumnsKey() { return 'Db.Table'; }
        protected getDialogType() { return TableDialog; }
        protected getIdProperty() { return TableRow.idProperty; }
        protected getInsertPermission() { return TableRow.insertPermission; }
        protected getLocalTextPrefix() { return TableRow.localTextPrefix; }
        protected getService() { return TableService.baseUrl; }

        constructor(container: JQuery) {
            super(container);
        }

        protected getButtons(): Serenity.ToolButton[] {
            var buttons = super.getButtons();
            //移除新增按钮
            buttons.splice(Q.indexOf(buttons, x => x.cssClass == "add-button"), 1);
            return buttons;
        }

        protected getSlickOptions() {
            let opt = super.getSlickOptions();
            opt.enableTextSelectionOnCells = true
            return opt;
        }
    }
}