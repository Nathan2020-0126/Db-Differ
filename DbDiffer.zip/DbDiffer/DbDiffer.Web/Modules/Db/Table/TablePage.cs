﻿
namespace DbDiffer.Db.Pages
{
    using Serenity;
    using Serenity.Web;
    using Microsoft.AspNetCore.Mvc;

    [PageAuthorize(typeof(Entities.TableRow))]
    public class TableController : Controller
    {
        [Route("Db/Table")]
        public ActionResult Index()
        {
            return View("~/Modules/Db/Table/TableIndex.cshtml");
        }
    }
}