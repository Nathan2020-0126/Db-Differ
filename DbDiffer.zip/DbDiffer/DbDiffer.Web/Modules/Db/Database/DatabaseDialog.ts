﻿
namespace DbDiffer.Db {

    @Serenity.Decorators.registerClass()
    export class DatabaseDialog extends Serenity.EntityDialog<DatabaseRow, any> {
        protected getFormKey() { return DatabaseForm.formKey; }
        protected getIdProperty() { return DatabaseRow.idProperty; }
        protected getLocalTextPrefix() { return DatabaseRow.localTextPrefix; }
        protected getNameProperty() { return DatabaseRow.nameProperty; }
        protected getService() { return DatabaseService.baseUrl; }
        protected getDeletePermission() { return DatabaseRow.deletePermission; }
        protected getInsertPermission() { return DatabaseRow.insertPermission; }
        protected getUpdatePermission() { return DatabaseRow.updatePermission; }

        protected form = new DatabaseForm(this.idPrefix);

    }
}