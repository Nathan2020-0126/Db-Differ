﻿
namespace DbDiffer.Db.Forms
{
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using System;
    using System.ComponentModel;
    using System.Collections.Generic;
    using System.IO;

    [FormScript("Db.Database")]
    [BasedOnRow(typeof(Entities.DatabaseRow), CheckNames = true)]
    public class DatabaseForm
    {
        public String DatabaseName { get; set; }
        public String ConnectionString { get; set; }
    }
}