﻿
namespace DbDiffer.Db.Columns
{
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using System;
    using System.ComponentModel;
    using System.Collections.Generic;
    using System.IO;

    [ColumnsScript("Db.Database")]
    [BasedOnRow(typeof(Entities.DatabaseRow), CheckNames = true)]
    public class DatabaseColumns
    {
        [EditLink]
        public String DatabaseName { get; set; }
        public String ConnectionString { get; set; }
    }
}