﻿
namespace DbDiffer.Db.Pages
{
    using Serenity;
    using Serenity.Web;
    using Microsoft.AspNetCore.Mvc;

    [PageAuthorize(typeof(Entities.DatabaseRow))]
    public class DatabaseController : Controller
    {
        [Route("Db/Database")]
        public ActionResult Index()
        {
            return View("~/Modules/Db/Database/DatabaseIndex.cshtml");
        }
    }
}