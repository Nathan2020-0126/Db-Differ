﻿
namespace DbDiffer.Db.Entities
{
    using Mom.Administration.Entities;
    using Serenity;
    using Serenity.ComponentModel;
    using Serenity.Data;
    using Serenity.Data.Mapping;
    using System;
    using System.ComponentModel;
    using System.IO;

    [ConnectionKey("Northwind"), Module("Db"), TableName("[dbo].[Databases]")]
    [DisplayName("数据库"), InstanceName("数据库")]
    [ReadPermission("*")]
    [ModifyPermission("*")]
    [LookupScript]
    public sealed class DatabaseRow : LoggingAllRow, IIdRow, INameRow
    {
        [DisplayName("Id"), NotNull]
        public Guid? DatabaseId
        {
            get { return Fields.DatabaseId[this]; }
            set { Fields.DatabaseId[this] = value; }
        }

        [DisplayName("数据库名称"), Size(500), NotNull, QuickSearch]
        public String DatabaseName
        {
            get { return Fields.DatabaseName[this]; }
            set { Fields.DatabaseName[this] = value; }
        }

        [DisplayName("连接语句"), Size(500), NotNull]
        public String ConnectionString
        {
            get { return Fields.ConnectionString[this]; }
            set { Fields.ConnectionString[this] = value; }
        }

        IIdField IIdRow.IdField
        {
            get { return Fields.DatabaseId; }
        }

        StringField INameRow.NameField
        {
            get { return Fields.DatabaseName; }
        }

        public static readonly RowFields Fields = new RowFields().Init();

        public DatabaseRow()
            : base(Fields)
        {
        }

        public class RowFields : LoggingAllRowFields
        {
            public GuidField DatabaseId;
            public StringField DatabaseName;
            public StringField ConnectionString;
        }
    }
}
