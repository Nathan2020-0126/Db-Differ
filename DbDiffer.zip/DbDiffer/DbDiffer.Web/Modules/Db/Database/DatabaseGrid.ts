﻿
namespace DbDiffer.Db {

    @Serenity.Decorators.registerClass()
    export class DatabaseGrid extends Serenity.EntityGrid<DatabaseRow, any> {
        protected getColumnsKey() { return 'Db.Database'; }
        protected getDialogType() { return DatabaseDialog; }
        protected getIdProperty() { return DatabaseRow.idProperty; }
        protected getInsertPermission() { return DatabaseRow.insertPermission; }
        protected getLocalTextPrefix() { return DatabaseRow.localTextPrefix; }
        protected getService() { return DatabaseService.baseUrl; }

        constructor(container: JQuery) {
            super(container);
        }

        protected getColumns() {
            var columns = super.getColumns();

            columns.splice(1, 0, {
                field: 'Print Invoice',
                name: '',
                format: ctx => '<a class="inline-action get-content" title="刷新数据库表和字段">' +
                    '<i class="fa fa-refresh text-red"></i></a>',
                width: 24,
                minWidth: 24,
                maxWidth: 24
            });

            return columns;
        }

        protected onClick(e: JQueryEventObject, row: number, cell: number) {
            super.onClick(e, row, cell);

            if (e.isDefaultPrevented())
                return;

            var item = this.itemAt(row);
            var target = $(e.target);

            // if user clicks "i" element, e.g. icon
            if (target.parent().hasClass('inline-action'))
                target = target.parent();

            if (target.hasClass('inline-action')) {
                e.preventDefault();

                if (target.hasClass('get-content')) {
                    Db.Services.CompareService.GetDbContent({
                        GuidId: item.DatabaseId
                    }, r => {
                            Q.notifySuccess("刷新成功!");
                            this.refresh()
                    });
                }
            }
        }
    }
}