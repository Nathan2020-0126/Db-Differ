﻿
namespace DbDiffer.Administration
{
    using Serenity.Services;

    public class RolePermissionListResponse : ListResponse<string>
    {
    }
}