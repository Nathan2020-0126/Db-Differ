﻿using Serenity.Navigation;
using Administration = DbDiffer.Administration.Pages;

[assembly: NavigationLink(1, "Dashboard", url: "~/", permission: "", icon: "fa-tachometer")]
