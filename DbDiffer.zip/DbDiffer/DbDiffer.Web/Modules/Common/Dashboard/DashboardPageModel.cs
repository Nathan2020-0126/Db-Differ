﻿
namespace DbDiffer.Common
{
    public class DashboardPageModel
    {
        public int DbCount { get; set; }
        public int TableCount { get; set; }
        public int TableColumnCount { get; set; }
        public int UserCount { get; set; }
    }
}