﻿
namespace DbDiffer.Common.Pages
{
    using Serenity;
    using Serenity.Data;
    using Serenity.Web;
    using System;
    using Microsoft.AspNetCore.Mvc;
    using DbDiffer.Db.Entities;
    using Mom.Common.Enum;
    using DbDiffer.Administration.Entities;

    [Route("Dashboard/[action]")]
    public class DashboardController : Controller
    {
        [PageAuthorize, HttpGet, Route("~/")]
        public ActionResult Index()
        {
            var cachedModel = TwoLevelCache.GetLocalStoreOnly("DashboardPageModel", TimeSpan.FromMinutes(5),
                DatabaseRow.Fields.GenerationKey, () =>
                {
                    var model = new DashboardPageModel();
                    using (var connection = SqlConnections.NewFor<DatabaseRow>())
                    {
                        model.DbCount = connection.Count<DatabaseRow>(DatabaseRow.Fields.IsActive==(Int16)ActiveStatus.Active);
                        model.TableCount = connection.Count<TableRow>(TableRow.Fields.IsActive == (Int16)ActiveStatus.Active);
                        model.TableColumnCount = connection.Count<TableColumnRow>(TableColumnRow.Fields.IsActive == (Int16)ActiveStatus.Active);
                        model.UserCount = connection.Count<UserRow>(UserRow.Fields.IsActive == (Int16)ActiveStatus.Active);
                   }
                    return model;
                });
            return View(MVC.Views.Common.Dashboard.DashboardIndex, cachedModel);
        }
    }
}
