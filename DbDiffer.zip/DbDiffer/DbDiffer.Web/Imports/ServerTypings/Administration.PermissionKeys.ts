﻿namespace DbDiffer.Administration {
    declare namespace PermissionKeys {
        export const Security = "Administration:Security";
        export const Translation = "Administration:Translation";
    }
}
