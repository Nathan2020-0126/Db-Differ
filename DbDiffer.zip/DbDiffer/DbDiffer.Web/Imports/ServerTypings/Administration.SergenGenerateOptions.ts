﻿namespace DbDiffer.Administration {
    export interface SergenGenerateOptions {
        Row?: boolean;
        Service?: boolean;
        UI?: boolean;
    }
}
