﻿namespace Mom.Common.Enum {
    export enum ActiveStatus {
        Deleted = -1,
        Inactive = 0,
        Active = 1
    }
    Serenity.Decorators.registerEnumType(ActiveStatus, 'Mom.Common.Enum.ActiveStatus', 'Commom.ActiveStatus');
}
