﻿namespace DbDiffer.Administration {
    export interface SergenConnection {
        Key?: string;
    }
}
