﻿namespace DbDiffer.Db {
    export interface TableColumnForm {
        Table_Name: Serenity.LookupEditor;
        Name: Serenity.StringEditor;
        Item: Serenity.IntegerEditor;
        IsIdentity: Serenity.BooleanEditor;
        IsPk: Serenity.BooleanEditor;
        Type: Serenity.StringEditor;
        OccupiedBytes: Serenity.IntegerEditor;
        Length: Serenity.IntegerEditor;
        DecimalPlaces: Serenity.IntegerEditor;
        Isnullable: Serenity.BooleanEditor;
        DefaultValue: Serenity.StringEditor;
        Description: Serenity.StringEditor;
    }

    export class TableColumnForm extends Serenity.PrefixedContext {
        static formKey = 'Db.TableColumn';
        private static init: boolean;

        constructor(prefix: string) {
            super(prefix);

            if (!TableColumnForm.init)  {
                TableColumnForm.init = true;

                var s = Serenity;
                var w0 = s.LookupEditor;
                var w1 = s.StringEditor;
                var w2 = s.IntegerEditor;
                var w3 = s.BooleanEditor;

                Q.initFormType(TableColumnForm, [
                    'Table_Name', w0,
                    'Name', w1,
                    'Item', w2,
                    'IsIdentity', w3,
                    'IsPk', w3,
                    'Type', w1,
                    'OccupiedBytes', w2,
                    'Length', w2,
                    'DecimalPlaces', w2,
                    'Isnullable', w3,
                    'DefaultValue', w1,
                    'Description', w1
                ]);
            }
        }
    }
}
