﻿namespace DbDiffer.Db {
    export interface TableColumnRow {
        TableColumnId?: string;
        DatabaseId?: string;
        DatabaseName?: string;
        Table_Name?: string;
        Name?: string;
        Item?: number;
        IsIdentity?: boolean;
        IsPk?: boolean;
        Type?: string;
        OccupiedBytes?: number;
        Length?: number;
        DecimalPlaces?: number;
        Isnullable?: boolean;
        DefaultValue?: string;
        Description?: string;
        InsertUserId?: number;
        InsertUserDisplayName?: string;
        InsertUserName?: string;
        InsertDate?: string;
        UpdateUserId?: number;
        UpdateUserDisplayName?: string;
        UpdateDate?: string;
        DeleteUserId?: number;
        DeleteUserDisplayName?: string;
        DeleteDate?: string;
        IsActive?: Mom.Common.Enum.ActiveStatus;
    }

    export namespace TableColumnRow {
        export const idProperty = 'TableColumnId';
        export const isActiveProperty = 'IsActive';
        export const nameProperty = 'Name';
        export const localTextPrefix = 'Db.TableColumn';
        export const lookupKey = 'Db.TableColumn';

        export function getLookup(): Q.Lookup<TableColumnRow> {
            return Q.getLookup<TableColumnRow>('Db.TableColumn');
        }
        export const deletePermission = '*';
        export const insertPermission = '*';
        export const readPermission = '*';
        export const updatePermission = '*';

        export declare const enum Fields {
            TableColumnId = "TableColumnId",
            DatabaseId = "DatabaseId",
            DatabaseName = "DatabaseName",
            Table_Name = "Table_Name",
            Name = "Name",
            Item = "Item",
            IsIdentity = "IsIdentity",
            IsPk = "IsPk",
            Type = "Type",
            OccupiedBytes = "OccupiedBytes",
            Length = "Length",
            DecimalPlaces = "DecimalPlaces",
            Isnullable = "Isnullable",
            DefaultValue = "DefaultValue",
            Description = "Description",
            InsertUserId = "InsertUserId",
            InsertUserDisplayName = "InsertUserDisplayName",
            InsertUserName = "InsertUserName",
            InsertDate = "InsertDate",
            UpdateUserId = "UpdateUserId",
            UpdateUserDisplayName = "UpdateUserDisplayName",
            UpdateDate = "UpdateDate",
            DeleteUserId = "DeleteUserId",
            DeleteUserDisplayName = "DeleteUserDisplayName",
            DeleteDate = "DeleteDate",
            IsActive = "IsActive"
        }
    }
}
