﻿namespace DbDiffer.Db {
    export interface DatabaseRow {
        DatabaseId?: string;
        DatabaseName?: string;
        ConnectionString?: string;
        InsertUserId?: number;
        InsertUserDisplayName?: string;
        InsertUserName?: string;
        InsertDate?: string;
        UpdateUserId?: number;
        UpdateUserDisplayName?: string;
        UpdateDate?: string;
        DeleteUserId?: number;
        DeleteUserDisplayName?: string;
        DeleteDate?: string;
        IsActive?: Mom.Common.Enum.ActiveStatus;
    }

    export namespace DatabaseRow {
        export const idProperty = 'DatabaseId';
        export const isActiveProperty = 'IsActive';
        export const nameProperty = 'DatabaseName';
        export const localTextPrefix = 'Db.Database';
        export const lookupKey = 'Db.Database';

        export function getLookup(): Q.Lookup<DatabaseRow> {
            return Q.getLookup<DatabaseRow>('Db.Database');
        }
        export const deletePermission = '*';
        export const insertPermission = '*';
        export const readPermission = '*';
        export const updatePermission = '*';

        export declare const enum Fields {
            DatabaseId = "DatabaseId",
            DatabaseName = "DatabaseName",
            ConnectionString = "ConnectionString",
            InsertUserId = "InsertUserId",
            InsertUserDisplayName = "InsertUserDisplayName",
            InsertUserName = "InsertUserName",
            InsertDate = "InsertDate",
            UpdateUserId = "UpdateUserId",
            UpdateUserDisplayName = "UpdateUserDisplayName",
            UpdateDate = "UpdateDate",
            DeleteUserId = "DeleteUserId",
            DeleteUserDisplayName = "DeleteUserDisplayName",
            DeleteDate = "DeleteDate",
            IsActive = "IsActive"
        }
    }
}
