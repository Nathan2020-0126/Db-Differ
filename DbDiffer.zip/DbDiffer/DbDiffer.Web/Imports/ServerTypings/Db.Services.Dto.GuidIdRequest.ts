﻿namespace DbDiffer.Db.Services.Dto {
    export interface GuidIdRequest extends Serenity.ServiceRequest {
        GuidId?: string;
    }
}
