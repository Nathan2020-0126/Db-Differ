﻿namespace DbDiffer.Db {
    export interface TableForm {
        Name: Serenity.StringEditor;
        Module: Serenity.LookupEditor;
        Description: Serenity.StringEditor;
    }

    export class TableForm extends Serenity.PrefixedContext {
        static formKey = 'Db.Table';
        private static init: boolean;

        constructor(prefix: string) {
            super(prefix);

            if (!TableForm.init)  {
                TableForm.init = true;

                var s = Serenity;
                var w0 = s.StringEditor;
                var w1 = s.LookupEditor;

                Q.initFormType(TableForm, [
                    'Name', w0,
                    'Module', w1,
                    'Description', w0
                ]);
            }
        }
    }
}
