﻿namespace DbDiffer.Db {
    export interface DatabaseForm {
        DatabaseName: Serenity.StringEditor;
        ConnectionString: Serenity.StringEditor;
    }

    export class DatabaseForm extends Serenity.PrefixedContext {
        static formKey = 'Db.Database';
        private static init: boolean;

        constructor(prefix: string) {
            super(prefix);

            if (!DatabaseForm.init)  {
                DatabaseForm.init = true;

                var s = Serenity;
                var w0 = s.StringEditor;

                Q.initFormType(DatabaseForm, [
                    'DatabaseName', w0,
                    'ConnectionString', w0
                ]);
            }
        }
    }
}
