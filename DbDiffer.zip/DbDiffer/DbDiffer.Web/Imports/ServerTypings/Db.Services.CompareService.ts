﻿namespace DbDiffer.Db.Services {
    export namespace CompareService {
        export const baseUrl = 'Db/CompareService';

        export declare function GetDbContent(request: Db.Services.Dto.GuidIdRequest, onSuccess?: (response: Serenity.ServiceResponse) => void, opt?: Q.ServiceOptions<any>): JQueryXHR;
        export declare function ChangeTableColumnDescription(request: Db.Services.Dto.ChangeTableColumnDescriptionRequest, onSuccess?: (response: Serenity.ServiceResponse) => void, opt?: Q.ServiceOptions<any>): JQueryXHR;

        export declare const enum Methods {
            GetDbContent = "Db/CompareService/GetDbContent",
            ChangeTableColumnDescription = "Db/CompareService/ChangeTableColumnDescription"
        }

        [
            'GetDbContent', 
            'ChangeTableColumnDescription'
        ].forEach(x => {
            (<any>CompareService)[x] = function (r, s, o) {
                return Q.serviceRequest(baseUrl + '/' + x, r, s, o);
            };
        });
    }
}
