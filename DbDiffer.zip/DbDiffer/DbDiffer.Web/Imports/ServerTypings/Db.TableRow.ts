﻿namespace DbDiffer.Db {
    export interface TableRow {
        Id?: string;
        DatabaseId?: string;
        DatabaseName?: string;
        Module?: string;
        Name?: string;
        ObjectId?: string;
        CreateDate?: string;
        ModifyDate?: string;
        ColumnCount?: number;
        Description?: string;
        InsertUserId?: number;
        InsertUserDisplayName?: string;
        InsertUserName?: string;
        InsertDate?: string;
        UpdateUserId?: number;
        UpdateUserDisplayName?: string;
        UpdateDate?: string;
        DeleteUserId?: number;
        DeleteUserDisplayName?: string;
        DeleteDate?: string;
        IsActive?: Mom.Common.Enum.ActiveStatus;
    }

    export namespace TableRow {
        export const idProperty = 'Id';
        export const isActiveProperty = 'IsActive';
        export const nameProperty = 'Name';
        export const localTextPrefix = 'Db.Table';
        export const lookupKey = 'Db.Table';

        export function getLookup(): Q.Lookup<TableRow> {
            return Q.getLookup<TableRow>('Db.Table');
        }
        export const deletePermission = '*';
        export const insertPermission = '*';
        export const readPermission = '*';
        export const updatePermission = '*';

        export declare const enum Fields {
            Id = "Id",
            DatabaseId = "DatabaseId",
            DatabaseName = "DatabaseName",
            Module = "Module",
            Name = "Name",
            ObjectId = "ObjectId",
            CreateDate = "CreateDate",
            ModifyDate = "ModifyDate",
            ColumnCount = "ColumnCount",
            Description = "Description",
            InsertUserId = "InsertUserId",
            InsertUserDisplayName = "InsertUserDisplayName",
            InsertUserName = "InsertUserName",
            InsertDate = "InsertDate",
            UpdateUserId = "UpdateUserId",
            UpdateUserDisplayName = "UpdateUserDisplayName",
            UpdateDate = "UpdateDate",
            DeleteUserId = "DeleteUserId",
            DeleteUserDisplayName = "DeleteUserDisplayName",
            DeleteDate = "DeleteDate",
            IsActive = "IsActive"
        }
    }
}
