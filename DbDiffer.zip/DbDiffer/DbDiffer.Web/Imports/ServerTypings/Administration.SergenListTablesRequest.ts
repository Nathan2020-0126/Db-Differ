﻿namespace DbDiffer.Administration {
    export interface SergenListTablesRequest extends Serenity.ServiceRequest {
        ConnectionKey?: string;
    }
}
