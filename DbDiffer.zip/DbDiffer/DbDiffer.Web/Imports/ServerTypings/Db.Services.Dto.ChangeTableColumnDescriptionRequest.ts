﻿namespace DbDiffer.Db.Services.Dto {
    export interface ChangeTableColumnDescriptionRequest extends Serenity.ServiceRequest {
        TableColumnId?: string;
        NewDescription?: string;
    }
}
